package com.ezen.book.service;

import java.util.List;

import com.ezen.book.domain.NoticeVO;
import com.ezen.book.domain.PagingVO;

public interface NoticeService {

	List<NoticeVO> getNoticeList(PagingVO pvo);

	NoticeVO getDetail(int ntc_num);

	int noticeRegister(NoticeVO nvo);

	int getModify(NoticeVO nvo);

	int getDelete(int ntc_num);

	int getTotalCount(PagingVO pvo);

	List<NoticeVO> getNoticeListOnly(PagingVO pvo);

}
